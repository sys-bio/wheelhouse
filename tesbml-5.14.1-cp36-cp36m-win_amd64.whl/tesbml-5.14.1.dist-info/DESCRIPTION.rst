LibSBML is a library for reading, writing and manipulating the Systems Biology Markup Language (SBML).  It is written in ISO C and C++, supports SBML Levels 1, 2 and 3, and runs on Linux, Microsoft Windows, and Apple MacOS X.  For more information about SBML, please see http://sbml.org.


