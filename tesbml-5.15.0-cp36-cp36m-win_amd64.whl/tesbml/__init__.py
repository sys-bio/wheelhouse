from .libsbml import *
__version__ = getLibSBMLDottedVersion()
