from rrplugins.telplugins import *
from rrplugins.telplugins_c_api import *

__version__ = '1.1.8'
