libSEDML is a library for reading, writing and manipulating SEDML. It is written in ISO C and C++, supports SEDML Levels 1, Version 1-3, and runs on Linux, Microsoft Windows, and Apple MacOS X. For more information about SEDML, please see http://sed-ml.org/.


